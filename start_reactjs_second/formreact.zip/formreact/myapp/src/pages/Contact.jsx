const Contact =()=>{
    return(
        <>
        </>
    )
}

export default Contact;