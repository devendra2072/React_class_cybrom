
import Cybrom from "./cybrom";
    const Bhopal =()=>{
    return(
        <>
        <h1> welcome :</h1>
        <Cybrom/>
        </>
    )
}

export default Bhopal;