
// import { BrowserRouter,Routes,Route } from "react-router-dom";
// import Layout from "./Layout";
// import Home from "./pages/Home";
// import About from "./pages/About";
// import Insert from "./pages/Insert";
// import Display from "./pages/Display";
// import Search from "./pages/Search";
// import Contact from "./pages/Contact";
// import Update from "./pages/Update";
// import Editdata from "./pages/Editdata";

// import Layout from "./Layout"
// import Home from "./pages/Home";
// import About from "./pages/About";
// import Contact from "./pages/Contact";
// import Insert from "./pages/Insert";
// import Display from "./pages/Display";
// import Search from "./pages/Search";
// import Update from "./pages/Update";




// function App() {
 

//   return (
//     <>
//       <h1>hello friends</h1>
//     <BrowserRouter>
//       <Routes>
        
//         <Route path="/" element={<Layout/>}>
//         <Route index element={<Home/>} />
//         <Route path="home" element={<Home/>} />
//         <Route path="about" element={<About/>} />
//         <Route path="insert" element={<Insert/>} />
//         <Route path="display" element={<Display/>} />
//         <Route path="search" element={<Search/>} />
//         <Route path="contact" element={<Contact/>} />
//         <Route path="update" element={<Update/>} />
//         <Route path="Editdata/:id" element={<Editdata/>}/>

//         </Route>
//       </Routes>
     
//     </BrowserRouter> 


//     </>
//   )
// }


// import { useState,createContext } from "react";
// import Comp1 from "./comp1";
// const mycontext=createContext();
// // const user="Nitesh Meena";
// function App(){
//   const[user,setuser]=useState("nitesh meena")
//   return(
//     <>
//        <h1>Welcome to my app : {user}</h1>
//        {/* <Comp1 /> */}
//        <mycontext.Provider value={{user}}>
//          <Comp1/>
//        </mycontext.Provider>
//     </>
//   )
// }


// export default App;
// export {mycontext};





import { useState,createContext } from "react";
import Bhopal from "./bhopal";
const colorcontext=createContext();
function App(){
  const[color,setcolor]=useState("yellow")
  return(
    <>
       <h1>Welcome to my app : {color}</h1>
       <button onClick={()=>{setcolor("red")}}>change color</button>
       <colorcontext.Provider value={{color,setcolor}}>
         <Bhopal/>
       </colorcontext.Provider>
    </>
  )
}


export default App;
export {colorcontext};
