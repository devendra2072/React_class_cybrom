import React from 'react';

const Home = () => {
    return (
        <>
        <h1>this is Home page</h1>
           <center><div style={{height:"200px", backgroundColor:"blue",width:"400px", alignItems:"center",marginTop:"100px",padding:"50px", borderRadius:"10px"}}>
                <div style={{backgroundColor:"yellow",height:"100px", width:"300px",padding:"50px", borderRadius:"10px"}}>
                    <div style={{backgroundColor:"red",width:"200px",height:"10px",textAlign:"center",padding:"50px"}}>CYBROM</div>
                </div>
            </div></center> 
        </>
    );
};

export default Home;