import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useState } from 'react';
import { addTask, deleteTask } from './todoSlice';


function App() {
  const [newTask, setNewTask] = useState()
  const dispatch = useDispatch()
  const t = useSelector(state => state.myslice.task)
  let s = 0;

  let ans = t.map((key) => {
    return (
      <>
        <tr>
          <td>{s++}</td>
          <td>{key.task}</td>
          <td><button onClick={() => { dispatch(deleteTask({ id: key.id })) }}>delete</button></td>
          <td><button onClick={() => { dispatch(deleteTask({ id: key.id })) }}>Edit</button></td>
        </tr>
      </>
    )
  })
  console.log(ans)

  return (
    <>
      app
      <input type="text" onChange={e => setNewTask(e.target.value)} />
      <button onClick={() => dispatch(addTask({ id: Date.now(), task: newTask }))}>add</button>
      <table border="3" style={{ width: "600px" }}>
        <th>sno</th>
        <th>task</th>
        <th>delete</th>
        {ans}
      </table>
    </>
  )
}

export default App