import { configureStore } from "@reduxjs/toolkit";
import slice from './todoSlice'
const store = configureStore({
    reducer: {
        myslice: slice
    }
});
export default store;
