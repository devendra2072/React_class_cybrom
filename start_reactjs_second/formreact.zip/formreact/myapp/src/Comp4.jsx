
import Comp5 from "./Comp5";

// const Comp4 =({user})=>{
    const Comp4 =()=>{
    return(
        <>
        <h1>comp 4</h1>
         {/* <Comp5 user={user}/>  */}
         <Comp5 /> 
        </>
    )
}

export default Comp4;