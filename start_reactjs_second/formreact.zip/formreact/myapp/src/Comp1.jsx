import Comp2 from "./Comp2";
// const Comp1 =({user})=>{
const Comp1 =()=>{
    return(
        <>
        <h1>comp 1</h1>
        {/* <Comp2 user={user}/> */}
        <Comp2 />
        </>
    )
}

export default Comp1;