const Contact=()=>{
   return(
      <>
         <h1>Contact page</h1>
      </>
   )
}
export default Contact;