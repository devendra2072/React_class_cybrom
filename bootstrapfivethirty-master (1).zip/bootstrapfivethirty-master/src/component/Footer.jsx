


const Footer=()=>{
    return(
        <>
         <div id="footer">
            <hr size="3" color="blue" />
            www.mymobileshop.com all right reserved 2025
         </div>
        </>
    )
}

export default Footer;