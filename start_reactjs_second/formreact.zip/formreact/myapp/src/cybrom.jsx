
import { useContext } from "react";
import { colorcontext } from "./App";

const Cybrom =()=>{
    const {color,setcolor}=useContext(colorcontext);
    return(
        <>
        <h1>welcome to cybrom : {color}</h1>
        <button onClick={()=>{setcolor("pink")}}>click here !!</button>
        </>
    )
}

export default Cybrom;