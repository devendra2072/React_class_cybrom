import { createSlice } from "@reduxjs/toolkit";
import { act } from "react";
const slice = createSlice({
    name: "myslice",
    initialState: {
        task: []
    },
    reducers: {
        addTask: (state, action) => {
            state.task.push(action.payload)
        },
        deleteTask: (state, action) => {
            console.log(action.payload.id)
            state.task = state.task.filter(key => key.id != action.payload.id);
        },
    }
});
export const { addTask, deleteTask } = slice.actions;
export default slice.reducer;