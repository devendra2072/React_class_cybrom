const Home=()=>{
   return(
      <>
         <h1>Welcome to home page</h1>
      </>
   )
}
export default Home;