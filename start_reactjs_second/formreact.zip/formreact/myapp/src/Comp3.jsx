import Comp4 from "./Comp4";
// const Comp3 =({user})=>{
    const Comp3 =()=>{
    return(
        <>
        <h1>comp 3</h1>
        {/* <Comp4 user={user}/> */}
        <Comp4/>
        </>
    )
}

export default Comp3;