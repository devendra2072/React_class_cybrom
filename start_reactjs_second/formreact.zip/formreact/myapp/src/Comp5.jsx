// const Comp5 =({user})=>{
import { mycontext } from "./App";
import { useContext } from "react";
    const Comp5 =()=>{
        const {user}=useContext(mycontext);
    return(
        <>
        <h1>comp 5 welcome :{user}</h1>
        </>
    )
}

export default Comp5;