const Home=()=>{
   return(
      <>
      <h1>Wlcome to Home Pages</h1>
      </>
   )
}
export default Home;