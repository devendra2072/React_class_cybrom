import axios from "axios";
import { useEffect, useState } from "react";
import editimg from "../images/edit-246.png";
import delimg from "../images/delimg.png";
import {useNavigate} from "react-router-dom";



const Update =()=>{
  const [mydata,setMydata]=useState([]);
  const navigate=useNavigate();
  const loaddata=async()=>{
    let api="http://localhost:3000/students";
    const response=await axios.get(api);
    setMydata(response.data);
  }

  useEffect(()=>{
    loaddata();
  },[])

  const mydel=async(id)=>{
    let api=`http://localhost:3000/students/${id}`;
    const response=await axios.delete(api);
    alert("deleted data");
    loaddata();
  }
  const myedit=(id)=>{
  navigate(`/Editdata/${id}`);
  }


  const ans=mydata.map((key)=>{
    return(
        <>
        <tr>
            <td>{key.empno}</td>
            <td>{key.name}</td>
            <td>{key.city}</td>
            <td>{key.mobile}</td>
            <td>{key.salary}</td>
            <td>
            
            <img src={editimg} width="30" height="30"
            onClick={()=>{myedit(key.id)}} />

            </td>
            <td>
            
            <img src={delimg} width="30" height="30"
            onClick={()=>{mydel(key.id)}} />

            </td>
        </tr>
        </>
    )
  })



    return(
        <>
        <h1>Update data</h1>
        <table>
            <tr>
                <th>empno</th>
                <th>name</th>
                <th>city</th>
                <th>mobile</th>
                <th>salary</th>
                <th>edit</th>
                <th>delete</th>
            </tr>
            {ans}
        </table>
        </>
    )
}

export default Update;