
import Comp3 from "./Comp3";
// const Comp2 =({user})=>{
const Comp2 =()=>{
    return(
        <>
        <h1>comp 2</h1>
         {/* <Comp3 user={user}/>  */}
        <Comp3/>
        </>
    )
}

export default Comp2;